import React, { useState, useEffect } from "react";
import { Download, Linkedin } from "lucide-react";
import { m, AnimatePresence } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";

const rolesEn = [
  "Web Developer",
  "Product Engineer",
  "UI/UX Designer",
  "Fullstack MERN Devs",
  "Value Translator"
];

const rolesId = [
  "Web Developer",
  "Product Engineer",
  "UI/UX Desainer",
  "Fullstack MERN Devs",
  "Value Translator"
];

const containerVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const sloganVariants = {
  hidden: { opacity: 0, y: 5, skewX: 0 },
  visible: {
    opacity: [0, 1, 0.35, 1, 0.6, 1],
    y: 0,
    skewX: [0, -10, 10, -5, 5, 0],
    transition: {
      delay: 0.8,
      duration: 0.4,
      ease: "linear",
    }
  }
};

export default function Home() {
  const { lang, t } = useLanguage();
  const [roleIndex, setRoleIndex] = useState(0);
  const roles = lang === "id" ? rolesId : rolesEn;

  useEffect(() => {
    const interval = setInterval(() => {
      setRoleIndex((prevIndex) => (prevIndex + 1) % roles.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [roles.length]);

  return (
    <m.section
      id="intro"
      className="scroll-mt-24 pt-4 flex flex-col gap-6"
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
    >
      {/* Small uppercase label */}
      <m.span
        className="text-[12px] font-bold tracking-[0.15em] text-[#8A8A8A] uppercase"
        variants={itemVariants}
      >
        {t("home.intro")}
      </m.span>

      {/* Quote Banner */}
      <m.div
        className="flex items-center gap-3 bg-[#0B0B0B] border border-white/5 w-fit py-2.5 px-4 rounded-full text-[13px] text-[#8A8A8A]"
        variants={itemVariants}
      >
        <div className="w-5 h-5 rounded-full overflow-hidden border border-white/10">
          <img
            src="/assets/icon aditya.webp"
            alt="Aditya Fajar SY"
            className="w-full h-full object-cover"
            width="20"
            height="20"
            loading="eager"
            decoding="async"
            onError={(e) => {
              e.target.src = "/assets/adityafajarsy.webp";
            }}
          />
        </div>
        <q className="italic">{t("home.quote")}</q>
      </m.div>

      {/* Main Title */}
      <m.div className="flex flex-col gap-1" variants={itemVariants}>
        <h2 className="text-[30px] min-[380px]:text-[34px] min-[410px]:text-[36px] lg:text-[44px] font-black tracking-tight leading-none text-white">
          {t("home.title")}
        </h2>
        <div className="h-[44px] lg:h-[54px] overflow-visible relative -mt-1 lg:-mt-1.5">
          <AnimatePresence mode="wait">
            <m.span
              key={roleIndex}
              initial={{ opacity: 0, x: 0, skewX: 0, scaleY: 1 }}
              animate={{
                opacity: [0, 1, 0.45, 1, 0.75, 1],
                x: [0, -6, 6, -3, 3, -1, 1, 0],
                skewX: [0, -12, 12, -6, 6, 0],
                scaleY: [1, 1.25, 0.75, 1.1, 0.9, 1],
              }}
              exit={{
                opacity: [1, 0.45, 0.75, 0.15, 0],
                x: [0, 5, -5, 2, -2, 0],
                skewX: [0, 8, -8, 4, -4, 0],
              }}
              transition={{
                duration: 0.35,
                ease: "linear",
              }}
              className="text-[32px] lg:text-[40px] font-semibold text-[#3B82F6] absolute left-0 leading-none"
              style={{ fontFamily: "'Nothing You Could Do', cursive" }}
            >
              {roles[roleIndex]}
            </m.span>
          </AnimatePresence>
        </div>
      </m.div>

      {/* Biography Description */}
      <m.p
        className="text-[16px] lg:text-[18px] leading-relaxed text-[#8A8A8A] max-w-4xl lg:max-w-5xl font-normal"
        variants={itemVariants}
      >
        {t("home.bio")}
      </m.p>

      {/* Action Buttons */}
      <m.div className="flex flex-wrap items-center gap-4 mt-2" variants={itemVariants}>
        <a
          href="/assets/CV-Terbaru.pdf"
          download="Aditya Fajar Satya Yudha-CV.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-5 py-3 rounded-full bg-white text-black font-semibold text-[14px] hover:bg-white/90 transition-all active:scale-95 shadow-md shadow-white/5"
        >
          <Download size={16} />
          <span>{t("home.downloadCv")}</span>
        </a>

        <a
          href="https://www.linkedin.com/in/adityafajarsy/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-5 py-3 rounded-full bg-[#0B0B0B] border border-white/5 text-white font-medium text-[14px] hover:border-[#3B82F6]/50 hover:bg-[#0F0F0F] transition-all active:scale-95 shadow-lg"
        >
          <Linkedin size={16} className="text-[#3B82F6]" />
          <span>{t("home.connectMe")}</span>
        </a>
      </m.div>
    </m.section>
  );
}
