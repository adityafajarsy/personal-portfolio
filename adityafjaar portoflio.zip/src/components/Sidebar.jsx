import React from "react";
import { Mail, Globe, Phone, MapPin } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { m } from "framer-motion";
import GithubActivity from "./GithubActivity";

const techStack = {
  frontend: ["React", "JavaScript", "TypeScript", "Tailwind"],
  backend: ["Node.js", "Express", "Python"],
  database: ["MongoDB", "PostgreSQL", "Supabase", "Firebase"],
  skills: ["Design Research", "UX", "User Research"],
  tools: ["Docker", "VS Code", "Antigravity", "Git"],
  design: ["Figma", "Canva"],
};

export default function Sidebar() {
  const { t } = useLanguage();
  const langList = t("sidebar.langList") || [];

  return (
    <aside className="w-full h-screen border-r border-white/5 bg-transparent overflow-y-auto px-[48px] pt-[80px] pb-[48px] flex flex-col gap-[32px] select-none">
      {/* Profile Header */}
      <div className="flex items-center justify-between gap-4">
        {/* Left Side: Avatar + Details */}
        <div className="flex flex-col gap-4">
          <div className="w-[80px] h-[80px] rounded-full overflow-hidden border-2 border-white/10 shadow-lg relative group flex-shrink-0">
            <img
              src="/assets/adityafajarsy.webp"
              alt="Aditya Fajar SY"
              className="w-full h-full object-cover object-[center_15%]"
              width="80"
              height="80"
              loading="eager"
              decoding="async"
              fetchpriority="high"
              onError={(e) => {
                e.target.src = "/assets/hero-img.webp";
              }}
            />
            <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-[24px] font-bold text-white tracking-tight leading-none">
                Aditya Fajar SY
              </h1>
              {/* Custom blue verification checkmark */}
              <svg
                viewBox="0 0 24 24"
                className="w-[18px] h-[18px] flex-shrink-0"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Badge Background */}
                <path
                  d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.99-3.818-3.99-.48 0-.927.1-1.34.28C14.843 2.5 13.518 1.5 12 1.5s-2.843 1-3.43 2.29c-.413-.18-.86-.28-1.34-.28-2.11 0-3.82 1.78-3.82 3.99 0 .495.084.965.238 1.4-1.273.65-2.148 2.02-2.148 3.6 0 1.58.875 2.95 2.148 3.6-.154.435-.238.905-.238 1.4 0 2.21 1.71 3.99 3.818 3.99.48 0 .927-.1 1.34-.28.587 1.29 1.912 2.29 3.43 2.29s2.843-1 3.43-2.29c.413.18.86.28 1.34.28 2.11 0 3.82-1.78 3.82-3.99 0-.495-.084-.965-.238-1.4 1.273-.65 2.148-2.02 2.148-3.6z"
                  fill="#3B82F6"
                />
                {/* Thick rounded checkmark */}
                <path
                  d="M8.3 12.3l2.7 2.7 5.7-5.7"
                  stroke="white"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  fill="none"
                />
              </svg>
            </div>
            <span className="text-[14px] text-[#8A8A8A] font-medium mt-1 inline-block">
              {t("sidebar.role")}
            </span>
          </div>
        </div>

        {/* Right Side: Large Rose decoration (Vertically Centered with Draw/Paint Animation) */}
        <m.div
          initial={{ clipPath: "inset(100% 0% 0% 0%)", opacity: 0, scale: 0.95 }}
          animate={{ clipPath: "inset(0% 0% 0% 0%)", opacity: 1, scale: 1 }}
          transition={{
            duration: 1.8,
            delay: 3.1,
            ease: [0.25, 1, 0.5, 1]
          }}
          className="w-[116px] h-[116px] relative flex items-center justify-center flex-shrink-0"
        >
          <img
            src="/assets/rose.webp"
            alt="Rose decoration"
            className="w-full h-full object-contain"
            width="116"
            height="116"
            loading="lazy"
            decoding="async"
          />
        </m.div>
      </div>

      {/* About / Bio */}
      <div className="flex flex-col gap-2">
        <h3 className="text-[12px] font-bold tracking-[0.15em] text-[#8A8A8A] uppercase">
          {t("sidebar.aboutTitle")}
        </h3>
        <p className="text-[14px] leading-relaxed text-[#8A8A8A] font-normal">
          {t("sidebar.aboutText")}
        </p>
      </div>

      {/* Contact Section */}
      <div className="flex flex-col gap-3">
        <h3 className="text-[12px] font-bold tracking-[0.15em] text-[#8A8A8A] uppercase">
          {t("sidebar.contactTitle")}
        </h3>
        <div className="flex flex-col gap-2.5 text-[14px] text-[#8A8A8A]">
          <a
            href="mailto:adityafajar.sy90@gmail.com"
            className="flex items-center gap-2.5 hover:text-white transition-colors duration-200"
          >
            <Mail size={16} className="text-[#8A8A8A]" />
            <span className="truncate">adityafajar.sy90@gmail.com</span>
          </a>
          <a
            href="https://github.com/adityafajarsy"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2.5 hover:text-white transition-colors duration-200"
          >
            <Globe size={16} className="text-[#8A8A8A]" />
            <span className="truncate">github.com/adityafajarsy</span>
          </a>
          <div className="flex items-center gap-2.5">
            <MapPin size={16} className="text-[#8A8A8A]" />
            <span>Jakarta, Indonesia</span>
          </div>
        </div>
      </div>

      {/* Tech Stack Section */}
      <div className="flex flex-col gap-3">
        <h3 className="text-[12px] font-bold tracking-[0.15em] text-[#8A8A8A] uppercase">
          {t("sidebar.techTitle")}
        </h3>
        <div className="flex flex-col gap-3">
          {Object.entries(techStack).map(([category, items]) => (
            <div key={category} className="flex flex-col gap-1.5">
              <span className="text-[11px] font-semibold text-[#8A8A8A] capitalize">
                {category}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {items.map((item) => (
                  <span
                    key={item}
                    className="text-[11px] font-medium text-white px-2 py-0.5 bg-[#0B0B0B] border border-white/5 rounded-md hover:border-[#3B82F6]/40 transition-colors duration-300"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* GitHub Activity Section */}
      <GithubActivity />

      {/* Languages Section */}
      <div className="flex flex-col gap-3">
        <h3 className="text-[12px] font-bold tracking-[0.15em] text-[#8A8A8A] uppercase">
          {t("sidebar.langTitle")}
        </h3>
        <div className="flex flex-wrap gap-1.5">
          {langList.map((lang) => (
            <span
              key={lang.name}
              className="flex items-center gap-1.5 text-[12px] font-medium text-white px-2.5 py-1 bg-[#0B0B0B] border border-white/5 rounded-full"
            >
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Social Icons Footer */}
      <div className="flex items-center gap-4 mt-auto pt-4 border-t border-white/5">
        <a
          href="https://github.com/adityafajarsy"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#8A8A8A] hover:text-white transition-colors duration-250"
          aria-label="GitHub"
        >
          <i className="ri-github-fill ri-xl"></i>
        </a>
        <a
          href="https://www.linkedin.com/in/adityafajarsy/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#8A8A8A] hover:text-white transition-colors duration-250"
          aria-label="LinkedIn"
        >
          <i className="ri-linkedin-fill ri-xl"></i>
        </a>
        <a
          href="https://instagram.com/adityafajarsyy"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#8A8A8A] hover:text-white transition-colors duration-250"
          aria-label="Instagram"
        >
          <i className="ri-instagram-line ri-xl"></i>
        </a>
        <a
          href="https://x.com/elonmusk"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#8A8A8A] hover:text-white/40 transition-colors duration-250 cursor-default"
          aria-label="X"
        >
          <i className="ri-twitter-x-fill ri-lg"></i>
        </a>
      </div>
    </aside>
  );
}
